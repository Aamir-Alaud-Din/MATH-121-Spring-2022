#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 23:15:09 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

t = np.linspace(0, 650, 1000)
x = 600 - 550*np.exp(-t/100)

plt.figure(figsize=(8, 8))
plt.plot(t, x, 'k')
plt.grid()
plt.xlabel("Time (min)", size=12, weight='bold')
plt.ylabel("Salt (lb)", size=12, weight='bold')
plt.show()