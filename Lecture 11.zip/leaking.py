#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 23:15:09 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

t = np.linspace(0, 46000, 1000)
h = (15 - 0.00032*t)**2

plt.figure(figsize=(8, 8))
plt.plot(t, h, 'k')
plt.grid()
plt.xlabel("Time (s)", size=12, weight='bold')
plt.ylabel("Volume ($cm^3$)", size=12, weight='bold')
plt.show()