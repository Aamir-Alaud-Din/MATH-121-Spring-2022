#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 23:15:09 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

A = 0.1
x = np.linspace(0, 58000, 1000)
y = 0.001*A*np.exp(-0.000012097*x)

plt.figure(figsize=(8, 8))
plt.plot(x, y, 'k')
plt.grid()
plt.xlabel("x-axis", size=12, weight='bold')
plt.ylabel("y-axis", size=12, weight='bold')
# plt.xlim([0, 3])
# plt.ylim([0, 0.4e07])
plt.show()