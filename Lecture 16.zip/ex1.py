#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 23:15:09 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

c = np.array([2, 3, 4, 5])
col = ['-k', '-r', '-g', '-b']

plt.figure(figsize=(12,6))
for i in range(len(c)):
	x1 = np.linspace(0, c[i], 1000)
	y1 = np.sqrt(c[i]*x1 - x1**2)
	plt.plot(x1, y1, col[i], x1, -y1, col[i], -x1, y1, col[i], -x1, -y1, col[i])
plt.xlabel("x-axis", size=12, weight='bold')
plt.ylabel("y-axis", size=12, weight='bold')
plt.show()
