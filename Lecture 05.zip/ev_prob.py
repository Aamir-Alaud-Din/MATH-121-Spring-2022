#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 23:15:09 2022

@author: aamir
"""

import numpy as np
import scipy as sp

a = np.array([1, 2, 1, 6, -1, 0, -1, -2, -1]).reshape(3, 3)
[val, vec] = np.linalg.eig(a)
print(val)
print(vec)

a = np.array([-2, 2, -3, 2, 1, -6, -1, -2, 0]).reshape(3, 3)
[val, vec] = np.linalg.eig(a)
print(val)
print(vec)

a = np.array([-5, 2, 2, -2]).reshape(2, 2)
[val, vec] = np.linalg.eig(a)
print(val)
print(vec)