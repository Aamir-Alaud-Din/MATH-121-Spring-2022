#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 23 16:14:55 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

x = np.linspace(-5, 5, 10)
y = x - 1
plt.figure(figsize=(8, 6))
plt.plot(x, y, linewidth=2, color='b')
plt.plot([0, 0], [-6, 4], linewidth=2, color='k')
plt.plot([-5, 5], [0, 0], linewidth=2, color='k')
plt.scatter(2, 1, s=50, c='g')
plt.text(2.3, 0.9, "(2, 1)")
plt.scatter(3, -1, s=50, c='r')
plt.text(3.3, -1.1, "(3, 1)")
plt.scatter(0, -1, s=50, c='g')
plt.text(0.3, -1.1, "(0, -1)")
plt.xlim([-5, 5])
plt.ylim([-6, 4])
plt.xlabel("x", size=12, weight='bold')
plt.ylabel("y", size=12, weight='bold')
plt.title("Plot of y = x -1")
plt.grid()
plt.savefig("line3", format="png")
plt.show()