#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 23 23:41:08 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

x = np.linspace(-5, 5, 100)
y = x**2
z = 10*np.ones(100)
plt.figure(figsize=(8, 6))
plt.plot(x, y, linewidth=2, color='b')
plt.plot(x, z, linewidth=2, color='b')
# plt.plot([0, 0], [-6, 4], linewidth=2, color='k')
# plt.plot([-5, 5], [0, 0], linewidth=2, color='k')
plt.scatter(-3.15, 10, s=50, c='g')
plt.text(-5, 8.8, "(-3.15, 10)")
plt.scatter(3.15, 10, s=50, c='g')
plt.text(3.3, 8.8, "(3.15, 10)")
plt.scatter(0, 0, s=50, c='r')
plt.text(-0.5, 1.0, "(0, 0)")
plt.scatter(0, 10, s=50, c='r')
plt.text(-0.5, 11, "(0, 10)")
plt.scatter(0, 20, s=50, c='r')
plt.text(-0.5, 21, "(0, 20)")
plt.xlabel("x", size=12, weight='bold')
plt.ylabel("y", size=12, weight='bold')
plt.title("Plot of $y=x^2$ and $z=10$")
plt.grid()
plt.savefig("parabola.png", format="png")
plt.show()