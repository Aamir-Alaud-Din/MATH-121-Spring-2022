#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 30 16:04:42 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator

def f1(x, y):
    return 7 - 2*x - 6*y

def f2(x, y):
    return x + 2*y + 1

def f3(x, y):
    return (5*x + 7*y - 9)/4

x = np.linspace(5, 15, 20)
y = np.linspace(-8, 2, 20)

X, Y = np.meshgrid(x, y)
Z1 = f1(X, Y)
Z2 = f2(X, Y)
Z3 = f3(X, Y)

fig = plt.figure()
ax = plt.axes(projection='3d')
# ax.contour3D(X, Y, Z1, 50, cmap='viridis')
# ax.contour3D(X, Y, Z2, 50, cmap='viridis')
# ax.contour3D(X, Y, Z3, 50, cmap='viridis')
ax.plot_wireframe(X, Y, Z1, color='grey')
ax.plot_wireframe(X, Y, Z2, color='grey')
ax.plot_wireframe(X, Y, Z3, color='grey')
ax.scatter(10, -3, 5, s=50, marker='o', c='r')
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
fig.tight_layout()
plt.show()