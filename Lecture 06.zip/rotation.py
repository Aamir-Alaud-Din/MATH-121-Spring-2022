#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr  7 06:06:20 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

def deg2rad(angle):
    return angle*(np.pi/180.0)

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

vertices = np.array([1, 1, -1, 1, -1, -1, 1, -1]).reshape(4, 2)
rot_angle = float(input("Enter the rotation angle: "))
rotation_mat = (np.array([np.cos(deg2rad(rot_angle)), -1*np.sin(deg2rad(rot_angle)), np.sin(deg2rad(rot_angle)), np.cos(deg2rad(rot_angle))]).reshape(2, 2))
rotated_mat = np.matmul(vertices, rotation_mat)


plt.figure()
plt.scatter(vertices[:, 0], vertices[:, 1], s=20, c='k')
plt.scatter(rotated_mat[:, 0], rotated_mat[:, 1], s=20, c='r')
plt.grid()
plt.xlabel("x-axis", size=12, weight='bold')
plt.ylabel("y-axis", size=12, weight='bold')
plt.show()