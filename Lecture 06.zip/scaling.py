#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 23:15:09 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

vertices = np.array([1, 1, -1, 1, -1, -1, 1, -1]).reshape(4, 2)
scale_factor = float(input("Enter the scaling factor: "))
scalar_mat = scale_factor*(np.array([1, 0, 0, 1]).reshape(2, 2))
print(vertices)
print(scalar_mat)
scaled_mat = np.matmul(vertices, scalar_mat)


plt.figure()
plt.scatter(vertices[:, 0], vertices[:, 1], s=20, c='k')
plt.scatter(scaled_mat[:, 0], scaled_mat[:, 1], s=20, c='r')
plt.grid()
plt.xlabel("x-axis", size=12, weight='bold')
plt.ylabel("y-axis", size=12, weight='bold')
plt.show()