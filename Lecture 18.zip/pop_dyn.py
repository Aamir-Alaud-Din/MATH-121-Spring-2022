#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 23:15:09 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

t = np.linspace(0, 13, 1000)
y = 1000/(1 + 999*np.exp(-0.9906*t))
tdots = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
ydots = 1000/(1 + 999*np.exp(-0.9906*tdots))

plt.figure(figsize=(10,6))
plt.plot(t, y, '-k')
plt.scatter(tdots, ydots, c='b')
plt.xlim([0, 13])
plt.xlabel("x-axis", size=12, weight='bold')
plt.ylabel("y-axis", size=12, weight='bold')
plt.grid()
plt.show()
