#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 30 16:04:42 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator

def f1(x, y):
    return x + y - 3

def f2(x, y):
    return (8 - 2*x + 2*y)/6

def f3(x, y):
    return (3*x + 5*y - 8)/7

x = np.linspace(-20, 20, 20)
y = np.linspace(-20, 20, 20)

X, Y = np.meshgrid(x, y)
Z1 = f1(X, Y)
Z2 = f2(X, Y)
Z3 = f3(X, Y)

fig = plt.figure()
ax = plt.axes(projection='3d')
# ax.contour3D(X, Y, Z1, 50, cmap='viridis')
# ax.contour3D(X, Y, Z2, 50, cmap='viridis')
# ax.contour3D(X, Y, Z3, 50, cmap='viridis')
ax.plot_wireframe(X, Y, Z1, color='grey')
ax.plot_wireframe(X, Y, Z2, color='grey')
ax.plot_wireframe(X, Y, Z3, color='grey')
# ax.scatter(10, -3, 5, s=50, marker='o', c='r')
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_zlabel('z')
fig.tight_layout()
plt.show()