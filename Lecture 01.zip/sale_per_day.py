#!/usr/bin/env pytyhon3
# -*- coding: <encoding-name> -*-i

# Program: sale_per_day.py
# Programmer: Aamir Alaud Din
# Date: 2022.03.22

# Objective(s):
#   To teach application of linear algebra in real life.

import numpy as np

units_sold = np.array([19, 22, 39, 16, 14, 1, 2, 12, 10, 7, 6, 8, 14, 5, 18,
    11, 17, 10]).reshape(6, 3)
unit_price = np.array([5000, 4000, 2500]).reshape(3, 1)

sale_per_day = np.dot(units_sold, unit_price)

days = np.array(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday',
    'Saturday'])

for i in range(len(days)):
    print("%-12sRs. %-.2f" % (days[i], sale_per_day[i]))
print()
print("Total = Rs. %-.2f" % np.sum(sale_per_day))





