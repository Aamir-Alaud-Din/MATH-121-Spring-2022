#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 23:15:09 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

x = np.linspace(-2, 2, 100)
c = np.array([-2, -1, 0, 1, 2])
y = [i*x for i in c]
colors = ['b', 'g', 'r', 'k', 'c']
texts = ['c=-2', 'c=-1', 'c=0', 'c=1', 'c=2']

plt.figure(figsize=(8, 6))
for i in range(5):
    plt.plot(x, y[i], colors[i])
    plt.text(-2.4, y[i][0], texts[i])
plt.xlim([-2.6, 2.1])
plt.grid()
plt.xlabel("x-axis", size=12, weight='bold')
plt.ylabel("y-axis", size=12, weight='bold')
plt.show()