#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 23:15:09 2022

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rc

rc('lines', linewidth=2)
rc('font', size=12, weight='bold')

x = np.linspace(-5, 5, 1000)
c = 25
y = np.sqrt(c - x**2)

plt.figure(figsize=(8, 8))
plt.plot(x, y, 'k')
plt.plot(x, -y, 'k')
plt.grid()
plt.xlabel("x-axis", size=12, weight='bold')
plt.ylabel("y-axis", size=12, weight='bold')
plt.show()